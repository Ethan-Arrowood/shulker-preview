# wait until a player is online to show status messages
execute if entity @a[limit=1] run schedule function ethan-arrowood.shulker_preview:meta/player_online 1s
execute unless entity @a[limit=1] run schedule function ethan-arrowood.shulker_preview:meta/await_player 2s
