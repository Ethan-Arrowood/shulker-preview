# dyeable items can be any color, so a macro is needed
data modify storage ethan-arrowood.shulker_preview:data item merge value {red:"a0",green:"65",blue:"40"}
execute store success score #has_color shulker_preview store result score #color shulker_preview run data get storage ethan-arrowood.shulker_preview:data item.components."minecraft:dyed_color".rgb
execute if score #has_color shulker_preview matches 1 run function ethan-arrowood.shulker_preview:render/convert_color
function ethan-arrowood.shulker_preview:render/row_2/special_render/dyeable2 with storage ethan-arrowood.shulker_preview:data item
