# analyze the contents of the container one item at a time
# any empty slot simply moves the cursor along
# at the end of each row, move the cursor back to the beginning and use a different set of characters for each height
data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:0}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:0}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:0}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:1}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:1}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:1}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:2}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:2}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:2}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:3}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:3}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:3}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:4}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:4}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:4}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:5}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:5}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:5}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:6}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:6}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:6}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:7}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:7}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:7}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:8}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:8}] run function ethan-arrowood.shulker_preview:render/row_0/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:8}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.row_end"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:9}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:9}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:9}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:10}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:10}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:10}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:11}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:11}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:11}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:12}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:12}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:12}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:13}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:13}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:13}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:14}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:14}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:14}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:15}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:15}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:15}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:16}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:16}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:16}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:17}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:17}] run function ethan-arrowood.shulker_preview:render/row_1/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:17}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.row_end"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:18}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:18}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:18}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:19}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:19}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:19}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:20}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:20}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:20}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:21}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:21}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:21}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:22}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:22}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:22}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:23}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:23}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:23}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:24}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:24}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:24}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:25}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:25}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:25}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}

data modify storage ethan-arrowood.shulker_preview:data item set from storage ethan-arrowood.shulker_preview:data contents[{slot:26}].item
execute if data storage ethan-arrowood.shulker_preview:data contents[{slot:26}] run function ethan-arrowood.shulker_preview:render/row_2/item
execute unless data storage ethan-arrowood.shulker_preview:data contents[{slot:26}] run data modify storage ethan-arrowood.shulker_preview:data tooltip append value {translate:"ethan-arrowood.shulker_preview.empty_slot"}
