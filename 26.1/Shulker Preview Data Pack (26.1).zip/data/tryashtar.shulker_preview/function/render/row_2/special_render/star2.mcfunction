# firework stars render with a base layer and a colored layer
$data modify storage tryashtar.shulker_preview:data tooltip append value [{translate:"tryashtar.shulker_preview.layer.$(id).0.2"},{translate:"tryashtar.shulker_preview.layer.$(id).1.2",color:"#$(red)$(green)$(blue)"}]
